create
    definer = root@localhost procedure num_from_employee(IN emp_id int, OUT count_num int)
BEGIN
		SELECT COUNT(*) INTO count_num
        FROM employee
        WHERE d_id = emp_id;
    END;

