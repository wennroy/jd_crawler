create
    definer = root@localhost function name_from_employee(emp_id int) returns varchar(20)
BEGIN
		RETURN (SELECT name
        FROM employee
        WHERE id=emp_id);
	END;

